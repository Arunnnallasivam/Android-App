package com.example.furnitureallocation;

import android.app.Activity;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.text.InputFilter;
import android.text.Spanned;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Spinner;
import android.widget.Toast;

public class AddLabAttendar extends Activity {
	Button btnSave;
	Button btnBack;
	
	EditText txtStaffCodeNo;
	EditText txtStaffName;
	//Spinner spnDepartment;
	//EditText txtGender;
	EditText txtMailId;
	EditText txtMobileNo;
	//EditText txtPassword;
	
	 private RadioGroup radioGroup;
	 private RadioButton radioButton;
	 String Gender="";
	
	SQLiteDatabase mydb=null;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_add_lab_attendar);
		
		mydb=openOrCreateDatabase(cls.dbname,MODE_PRIVATE ,null);
		mydb.execSQL("Create Table If Not Exists LabAttendarDetails(StaffId Varchar(50),StaffName Varchar(50),Gender Varchar(50),MailId Varchar(50),MobileNo Varchar(50),Password Varchar(50))");
		mydb.close();

		txtStaffCodeNo=(EditText)findViewById(R.id.txtStaffCodeNo);
		txtStaffName=(EditText)findViewById(R.id.txtStaffName);
		//txtDepartment=(EditText)findViewById(R.id.txtDepartment);
		//txtGender=(EditText)findViewById(R.id.txtGender);
		txtMailId=(EditText)findViewById(R.id.txtMailId);
		txtMobileNo=(EditText)findViewById(R.id.txtMobileNo);
		//txtPassword=(EditText)findViewById(R.id.txtPassword);
		
		btnSave=(Button)findViewById(R.id.btnSave);
		btnBack=(Button)findViewById(R.id.btnBack);
		
		myListener2 m=new myListener2();
		btnSave.setOnClickListener((OnClickListener) m);
		btnBack.setOnClickListener((OnClickListener) m);
		
		
		radioGroup = (RadioGroup) findViewById(R.id.radioGroup);
		
		//spnDepartment = (Spinner) findViewById(R.id.spnDepartment);
		//	String[] Stat ={"CSD","IS","AS"};
		//	spnDepartment.setOnItemSelectedListener(this);
		//	ArrayAdapter a1=new ArrayAdapter(this, android.R.layout.simple_spinner_item,Stat);
		//	spnDepartment.setAdapter(a1);
			
			
			//Validation
			//mobile number validation
			InputFilter filtertxt = new InputFilter(){
				@Override
				public CharSequence filter(CharSequence source, int start, int end, Spanned dest, int dstart, int dend) {
					// TODO Auto-generated method stub
					{
						for (int i = start; i < end; i++)
						{ 
			            	
			            	   if (!Character.isDigit(source.charAt(i)))
			            	   { 
			                            return ""; 
			                    } 
			                
			            } 
			            return null; 
					}
				}
			};
			txtMobileNo.setFilters( new InputFilter[]{filtertxt});
			
			
			// name validation
			InputFilter filtertxt1 = new InputFilter() {

				@SuppressWarnings("deprecation")
				@Override
				public CharSequence filter(CharSequence source, int start, int end, Spanned dest, int dstart, int dend) {
					
					for(int i=start;i<end;i++)
					{
						if(Character.isSpace(source.charAt(i)))
						{
							continue;
						}
						if(!Character.isLetter(source.charAt(i)))
						{
							return"";
						}
							
					}
					return null;
				} 
				
			};
			txtStaffName.setFilters(new InputFilter[]{filtertxt1});
			
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.add_lab_attendar, menu);
		return true;
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		// Handle action bar item clicks here. The action bar will
		// automatically handle clicks on the Home/Up button, so long
		// as you specify a parent activity in AndroidManifest.xml.
		int id = item.getItemId();
		if (id == R.id.action_settings) {
			return true;
		}
		return super.onOptionsItemSelected(item);
	}
	class myListener2 implements View.OnClickListener
	{
	@Override
	public void onClick(View v) {
	// TODO Auto-generated method stub

		switch(v.getId())
		{
		case R.id.btnSave:
			
	
	            
	            
	String s1=txtStaffCodeNo.getText().toString();
	if (s1.equals(""))
	{
	txtStaffCodeNo.requestFocus();
	return;
	}
	String s2=txtStaffName.getText().toString();
	if (s2.equals(""))
	{
	txtStaffName.requestFocus();
	return;
	}
	//String s3=spnDepartment.getSelectedItem().toString();
	//if (s3.equals(""))
	//{
	//	spnDepartment.requestFocus();
	//return;
	//}
	
	 int selectedId = radioGroup.getCheckedRadioButtonId();
     radioButton = (RadioButton) findViewById(selectedId);
	 String s4=radioButton.getText().toString();
	//if (s4.equals(""))
	//{
	//txtGender.requestFocus();
	//return;
	//}
	String s5=txtMailId.getText().toString();
	if (s5.equals(""))
	{
	txtMailId.requestFocus();
	return;
	}
	if(!(s5.contains("@")))
	{
		Toast.makeText(getApplicationContext(), "Should contain @ symbol", Toast.LENGTH_LONG).show();
		txtMailId.requestFocus();
	return;
	}

	if(!(s5.contains(".com")))
	{
		Toast.makeText(getApplicationContext(), "Should contain .com", Toast.LENGTH_LONG).show();
		txtMailId.requestFocus();
	return;
	}
	String s6=txtMobileNo.getText().toString();
	if (s6.equals(""))
	{
	txtMobileNo.requestFocus();
	return;
	}
	if((s6.toString().length()!=10) || cls.isNum(s6.toString())==false)
	{
		Toast.makeText(getApplicationContext(), "Mobile Number should contain 10 digits", Toast.LENGTH_LONG).show();
		txtMobileNo.requestFocus();
	return;
	}
	mydb=openOrCreateDatabase(cls.dbname,MODE_PRIVATE ,null);
	mydb.execSQL("Delete From LabAttendarDetails Where StaffId='" + s1 + "'");
	mydb.execSQL("Insert into LabAttendarDetails Values ('" + s1 + "','" + s2 + "','" + s4 + "','" + s5 + "','" + s6 + "','" + s7 + "')");
	mydb.close();
	Toast.makeText(getApplicationContext(), "Lab Attendar Details Saved", 1000).show();
	
	
	//String targetphnumberfr=txtMobileNo.getText().toString();
	 //SmsManager smsManager=SmsManager.getDefault();
  //smsManager.sendTextMessage(targetphnumberfr.toString(), null, "Id:" + s1 +":Password:" + s7, null, null);

	break;
	case R.id.btnBack:
	finish();
	break;
	}
	}
	}
}
