package com.example.furnitureallocation;


public class cls {
	public static String dbname="FurnitureAllocation";
	
	public static String EMailId="";
	public static String LoggedUserId="";
	public static String LoggedUserType="";

	public static String MobileNo="0000000000";
/////////////////////isNum
public static boolean isNum(String strNum)
{
boolean ret=true;
try
{
Double.parseDouble(strNum);
}catch(NumberFormatException e)
{
ret=false;	
}
return ret;
}
////////////////isNum
}
