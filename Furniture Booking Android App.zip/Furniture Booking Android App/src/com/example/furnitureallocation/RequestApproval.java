package com.example.furnitureallocation;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import android.app.Activity;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.Toast;

public class RequestApproval extends Activity {
Button b1,b2;
	
	Spinner spnRequestId,spnStatus;
	SQLiteDatabase mydb=null;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_request_approval);
		
		
		b1=(Button)findViewById(R.id.btnSave);
		b2=(Button)findViewById(R.id.btnBack);
		myListener1 m=new myListener1();
		b1.setOnClickListener((OnClickListener) m);
		b2.setOnClickListener((OnClickListener) m);
		
		mydb=openOrCreateDatabase(cls.dbname,MODE_PRIVATE ,null);
		mydb.execSQL("Create Table If Not Exists ApprovalDetails(RequestId Varchar(10),RequiredDate Varchar(10),FurnitureId Varchar(15),Status Varchar(20))");
		mydb.close();
        
		spnStatus= (Spinner) findViewById(R.id.spnStatus);
		ArrayList<String> RequestId = new ArrayList<String>();
		RequestId.add("Select");
		RequestId.add("Approve");	
		RequestId.add("Reject");
		ArrayAdapter<String> dataAdapter2 = new ArrayAdapter<String>(this,android.R.layout.simple_spinner_item, RequestId);
        dataAdapter2.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spnStatus.setAdapter(dataAdapter2);
        
        
        spnRequestId = (Spinner) findViewById(R.id.spnRequestId);
		mydb=openOrCreateDatabase(cls.dbname,MODE_PRIVATE ,null);
		Cursor cc=null;
		cc=mydb.rawQuery("Select RequestId,RequiredDate,FurnitureId From RequestDetails",null);
		cc.moveToFirst();
		ArrayList<String> CustId = new ArrayList<String>();
		CustId.add("Select");
		while(cc.isAfterLast()==false)
		{
			CustId.add(cc.getString(0) + ":" + cc.getString(1) + ":" + cc.getString(2));	
			cc.moveToNext();
		}
	    ArrayAdapter<String> dataAdapter1 = new ArrayAdapter<String>(this,android.R.layout.simple_spinner_item, CustId);
        dataAdapter1.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spnRequestId.setAdapter(dataAdapter1);
	    cc.close();
        mydb.close();
		
        
        //String tmprequestid=spnRequestId.getSelectedItem().toString().split(":")[0];
    	//String tmprequireddate=spnRequestId.getSelectedItem().toString().split(":")[1];
    	//String tmpfurniture=spnRequestId.getSelectedItem().toString().split(":")[2];
        
        spnRequestId.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener()
        {
          @Override
			public void onItemSelected(AdapterView<?> arg0, View arg1, int arg2, long arg3) {
			

				mydb=openOrCreateDatabase(cls.dbname,MODE_PRIVATE ,null);
           		Cursor c=mydb.rawQuery("Select RequestId,RequiredDate,FurnitureId,Status From ApprovalDetails Where RequestId='" + arg0.getSelectedItem().toString().split(":")[0] + "'", null);
				c.moveToFirst();
				while(c.isAfterLast()==false)
				{
					if((c.getString(1).equals(arg0.getSelectedItem().toString().split(":")[1]) && c.getString(2).equals(arg0.getSelectedItem().toString().split(":")[2]) && c.getString(3).equals("Approve")))
					{
					Toast.makeText(getApplicationContext(), "This request id" + c.getString(0) + "already approved", 1000).show();					
					b1.setEnabled(false);   //save button disabled
					}
					c.moveToNext();
				}
				c.close();
				mydb.close();	
			}
			@Override
			public void onNothingSelected(AdapterView<?> arg0) {
				
				
			}
        });
        
		
        
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.request_approval, menu);
		return true;
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		// Handle action bar item clicks here. The action bar will
		// automatically handle clicks on the Home/Up button, so long
		// as you specify a parent activity in AndroidManifest.xml.
		int id = item.getItemId();
		if (id == R.id.action_settings) {
			return true;
		}
		return super.onOptionsItemSelected(item);
	}
	
	class myListener1 implements View.OnClickListener
	{
	@Override
	public void onClick(View v) {
	//TODO Auto-generated method stub
		try
		{
	switch(v.getId())
	{
	case R.id.btnSave:

		try
		{
			
		
	//ApprovalDetails(RequestId Varchar(10),RequiredDate Varchar(10),FurnitureId Varchar(15),Status
	String requestid=spnRequestId.getSelectedItem().toString().split(":")[0];
	String requireddate=spnRequestId.getSelectedItem().toString().split(":")[1];
	String furniture=spnRequestId.getSelectedItem().toString().split(":")[2];
	String status=spnStatus.getSelectedItem().toString();

	
	mydb=openOrCreateDatabase(cls.dbname,MODE_PRIVATE ,null);
	Cursor c=mydb.rawQuery("Select Status From ApprovalDetails Where RequestId='" + requestid + "'", null);
	c.moveToFirst();
	if(c.isAfterLast()==false)
	{
		c.close();
		//if(c.getString(0).equals("Approve"))
		//{
			mydb.execSQL("Update ApprovalDetails Set Status='" + status + "' Where RequestId='" + requestid + "'");
			Toast.makeText(getApplicationContext(), "Approval Details Updated", Toast.LENGTH_LONG).show();
		//}
		//c.moveToNext();
	}
	else
	{
		c.close();
		mydb.execSQL("Insert into ApprovalDetails (RequestId ,RequiredDate ,FurnitureId , Status) Values('" + requestid + "','" + requireddate + "','" + furniture + "','"  + status + "')");
		Toast.makeText(getApplicationContext(), "Approval Details Saved", Toast.LENGTH_LONG).show();
	}

	
	mydb.close();	
	
	mydb=openOrCreateDatabase(cls.dbname,MODE_PRIVATE ,null);

	Cursor c1=mydb.rawQuery("Select StaffId From RequestDetails where RequestId='" + requestid + "'", null);
		c1.moveToFirst();
		
	String SMSstaffid="";
		 while(c1.isAfterLast()==false)
		{
			 SMSstaffid=c1.getString(0);
			  c1.moveToNext();
		}
		 
		c1.close();
		mydb.close();
		
		
		mydb=openOrCreateDatabase(cls.dbname,MODE_PRIVATE ,null);

		Cursor c2=mydb.rawQuery("Select MobileNo From StaffDetails where StaffId='" + SMSstaffid + "'", null);
			c2.moveToFirst();
			
			String targetphnumberfr="0000000000";
			 while(c2.isAfterLast()==false)
			{
				 SMSstaffid=c2.getString(0);
				  c2.moveToNext();
			}
			 SmsManager smsManager=SmsManager.getDefault();
			 smsManager.sendTextMessage(targetphnumberfr.toString(), null, "Request Id:" + requestid +" is " + status, null, null);
			c2.close();
			mydb.close();
		
		}
		catch(Exception e)
		{
			
		}
	
	
	
	
	break;
	case R.id.btnBack:
	finish();
	break;
	}
		}
		catch(Exception e)
		{
			Toast.makeText(getApplicationContext(), e.getMessage(), 1000).show();
		}
	}
	}
	
}
