package com.example.furnitureallocation;



import java.util.ArrayList;



import android.app.Activity;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.Color;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup.LayoutParams;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ScrollView;
import android.widget.Spinner;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;

public class SearchSeminarHallThings extends Activity {
	Button b1,b2;
	TextView t1;
	TableLayout tl1;
//	ScrollView sv;
	Spinner s1;
	SQLiteDatabase mydb=null;
	ArrayList<String> words=new ArrayList<String>();
	ArrayList<String> synwords=new ArrayList<String>();

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_search_seminar_hall_things);
		

		b1=(Button)findViewById(R.id.btnSearch);
		b2=(Button)findViewById(R.id.btnBack);
		myListener1 m=new myListener1();
		b1.setOnClickListener((OnClickListener) m);
		b2.setOnClickListener((OnClickListener) m);
		tl1 = (TableLayout)findViewById(R.id.myTableLayout);
		s1=(Spinner)findViewById(R.id.spnSeminarHallThings);
		mydb=openOrCreateDatabase(cls.dbname,MODE_PRIVATE ,null);
		Cursor c=null;	
		c=mydb.rawQuery("Select HallName From SeminarHallThings Group By HallName" ,null);
		c.moveToFirst();
		 ArrayList<String> users= new ArrayList<String>();
	       
			while(c.isAfterLast()==false)
			{
				users.add(c.getString(0));	
			c.moveToNext();
			}
			c.close();
			
	
		// Create an ArrayAdapter using the string array and a default spinner layout
		 
        // Creating adapter for spinner
        ArrayAdapter<String> dataAdapter11 = new ArrayAdapter<String>(this,android.R.layout.simple_spinner_item, users);
 
        // Drop down layout style - list view with radio button
        dataAdapter11.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        // attaching data adapter to spinner
        s1.setAdapter(dataAdapter11);
		//sv = (ScrollView)findViewById(R.id.scrollView01);
	/*	mydb=openOrCreateDatabase(cls.dbname,MODE_PRIVATE ,null);
		Cursor c=null;
//			if(cls.viewtype==4)
		//{
			//String contents=t1.getText().toString();
			
			
			c=mydb.rawQuery("Select * From SynonymWords",null);
			//Toast.makeText(ViewRecords.this, "Blood", Toast.LENGTH_LONG).show();		
		//}
		c.moveToFirst();
			while(c.isAfterLast()==false)
			{
				words.add(c.getString(0));
				synwords.add(c.getString(1));
				c.moveToNext();
			}

		c.close();
		mydb.close();*/
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.search_seminar_hall_things, menu);
		return true;
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		// Handle action bar item clicks here. The action bar will
		// automatically handle clicks on the Home/Up button, so long
		// as you specify a parent activity in AndroidManifest.xml.
		int id = item.getItemId();
		if (id == R.id.action_settings) {
			return true;
		}
		return super.onOptionsItemSelected(item);
	}
/////////////
class myListener1 implements View.OnClickListener
{
@Override
public void onClick(View v) {
// TODO Auto-generated method stub

switch(v.getId())
{
case R.id.btnSearch:
	mydb=openOrCreateDatabase(cls.dbname,MODE_PRIVATE ,null);
	Cursor c=null;
	
	String contents=s1.getSelectedItem().toString();

	c=mydb.rawQuery("Select * From SeminarHallThings Where HallName ='" + contents +"'",null);
	c.moveToFirst();
	
	tl1 = (TableLayout)findViewById(R.id.myTableLayout);
	tl1.removeAllViews();
	
	////Add new row in Table ayout
	 TableRow tr1 = new TableRow(getApplicationContext());
	 TextView b11 = new TextView(getApplicationContext());
	 b11.setText("THINGS DETAILS");
	 tr1.addView(b11);
     tl1.addView(tr1,new TableLayout.LayoutParams(LayoutParams.FILL_PARENT,LayoutParams.FILL_PARENT)); 
     tr1.setBackgroundColor(Color.BLUE);
	 ////////////////////////////
     
    // TableRow tr11 = new TableRow(this);
   //  TextView b12 = new TextView(this);
  //   b12.setText("Records List");
  //   tr11.addView(b12);
  //   tl1.addView(tr11,new TableLayout.LayoutParams(LayoutParams.FILL_PARENT,LayoutParams.FILL_PARENT));
  //   tr11.setBackgroundColor(Color.GREEN);
     //////////////////////////////
     
     TableRow trheader = new TableRow(getApplicationContext());
     TableRow trheader2 = new TableRow(getApplicationContext());
     TableRow trheader3 = new TableRow(getApplicationContext());
     TableRow trheader4 = new TableRow(getApplicationContext());
     TableRow trheader5 = new TableRow(getApplicationContext());
     TableRow trheader6 = new TableRow(getApplicationContext());
     TableRow trheader7 = new TableRow(getApplicationContext());
     TableRow trheader8 = new TableRow(getApplicationContext());
     
     TextView bheader1 = new TextView(getApplicationContext());
     TextView bheader2 = new TextView(getApplicationContext());
     TextView bheader3 = new TextView(getApplicationContext());
     TextView bheader4 = new TextView(getApplicationContext());
     TextView bheader5 = new TextView(getApplicationContext());
     TextView bheader6 = new TextView(getApplicationContext());
     TextView bheader7 = new TextView(getApplicationContext());
     TextView bheader8 = new TextView(getApplicationContext());
     
     
     tl1.addView(trheader,new TableLayout.LayoutParams(LayoutParams.FILL_PARENT,LayoutParams.FILL_PARENT));
     tl1.addView(trheader2,new TableLayout.LayoutParams(LayoutParams.FILL_PARENT,LayoutParams.FILL_PARENT));
     tl1.addView(trheader3,new TableLayout.LayoutParams(LayoutParams.FILL_PARENT,LayoutParams.FILL_PARENT));
     tl1.addView(trheader4,new TableLayout.LayoutParams(LayoutParams.FILL_PARENT,LayoutParams.FILL_PARENT));
     tl1.addView(trheader5,new TableLayout.LayoutParams(LayoutParams.FILL_PARENT,LayoutParams.FILL_PARENT));
     tl1.addView(trheader6,new TableLayout.LayoutParams(LayoutParams.FILL_PARENT,LayoutParams.FILL_PARENT));
     tl1.addView(trheader7,new TableLayout.LayoutParams(LayoutParams.FILL_PARENT,LayoutParams.FILL_PARENT));
     tl1.addView(trheader8,new TableLayout.LayoutParams(LayoutParams.FILL_PARENT,LayoutParams.FILL_PARENT));
      
     trheader.setBackgroundColor(Color.WHITE);
     trheader2.setBackgroundColor(Color.BLACK);
     trheader3.setBackgroundColor(Color.WHITE);
    
     bheader1.setText("Thing Id");
     trheader.addView(bheader1);
     
     bheader2.setText("Thing Name");
     trheader2.addView(bheader2);
     
     int rowcount=0;
     
          
     while (c.isAfterLast()==false)
     {
	
          
             TableRow tr = new TableRow(getApplicationContext());
             TableRow tr2 = new TableRow(getApplicationContext());
            
                  TextView b1 = new TextView(getApplicationContext());
                  b1.setText(c.getString(0));
                  //  b1.setWidth(50);
                 
                  TextView b2 = new TextView(getApplicationContext());
                  b2.setText(c.getString(1));
                  //b2.setWidth(150);
                  b2.setTextColor(Color.BLACK);
                    
                  
                 
			      
			      tr.addView(b1);
	              tr2.addView(b2);
	                               
				                    
	               
               
                  
                   tl1.addView(tr,new TableLayout.LayoutParams(LayoutParams.FILL_PARENT,LayoutParams.FILL_PARENT));
                   tl1.addView(tr2,new TableLayout.LayoutParams(LayoutParams.FILL_PARENT,LayoutParams.FILL_PARENT));
                      
                   if(rowcount%2==0)
                   {
                	   tr.setBackgroundColor(Color.BLUE);
                	  tr2.setBackgroundColor(Color.BLUE);
                
                	   b1.setTextColor(Color.WHITE);
                	   b2.setTextColor(Color.WHITE);
                	 
                   }
                   else
                   {
                	   tr.setBackgroundColor(Color.GREEN);
                		  tr2.setBackgroundColor(Color.GREEN);
                   	  
                	   b1.setTextColor(Color.BLACK);
                	   b2.setTextColor(Color.BLACK);
                	 
                   }
                   rowcount++;
                   c.moveToNext();
         }
	c.close();
//t1.setText(sb1.toString());
	mydb.close();

	break;
case R.id.btnBack:
	finish();
	break;
}
}
}
////////////////////////
}
