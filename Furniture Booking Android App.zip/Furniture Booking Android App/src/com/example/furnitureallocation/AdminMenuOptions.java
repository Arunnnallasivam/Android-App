package com.example.furnitureallocation;



import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;

public class AdminMenuOptions extends Activity {
	Button b1,b2,b3,b4,b5,b6,b7,b8,b9,b10,b11,b12,b13;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_admin_menu_options);
		
		b1=(Button)findViewById(R.id.btnAddStaff);
		b2=(Button)findViewById(R.id.btnAddFurnitureSet);
		b3=(Button)findViewById(R.id.btnAddSeminarHallThings);
		b4=(Button)findViewById(R.id.btnRequestApproval);
		b5=(Button)findViewById(R.id.btnViewAvailability);
		b6=(Button)findViewById(R.id.btnViewStaff);
		b7=(Button)findViewById(R.id.btnViewFurnitureSet);
		b8=(Button)findViewById(R.id.btnViewSeminarHallThings);
		b9=(Button)findViewById(R.id.btnExit);
		b10=(Button)findViewById(R.id.btnAddLabAttendar);
		b11=(Button)findViewById(R.id.btnViewLabAttendar);
		b12=(Button)findViewById(R.id.btnSearchApproval);
		b13=(Button)findViewById(R.id.btnViewFSAvailable);
		AdminMenuListener m=new AdminMenuListener();
		b1.setOnClickListener((OnClickListener) m);
		b2.setOnClickListener((OnClickListener) m);
		b3.setOnClickListener((OnClickListener) m);
		b4.setOnClickListener((OnClickListener) m);
		b5.setOnClickListener((OnClickListener) m);
		b6.setOnClickListener((OnClickListener) m);
		b7.setOnClickListener((OnClickListener) m);
		b8.setOnClickListener((OnClickListener) m);
		b9.setOnClickListener((OnClickListener) m);
		b10.setOnClickListener((OnClickListener) m);
		b11.setOnClickListener((OnClickListener) m);
		b12.setOnClickListener((OnClickListener) m);
		b13.setOnClickListener((OnClickListener) m);
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.admin_menu_options, menu);
		return true;
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		// Handle action bar item clicks here. The action bar will
		// automatically handle clicks on the Home/Up button, so long
		// as you specify a parent activity in AndroidManifest.xml.
		int id = item.getItemId();
		if (id == R.id.action_settings) {
			return true;
		}
		return super.onOptionsItemSelected(item);
	}
	class AdminMenuListener implements View.OnClickListener
	{
	@Override
	public void onClick(View v) {
	switch(v.getId())
	{
	case R.id.btnAddStaff:
	Intent i = new Intent(AdminMenuOptions.this,AddStaff.class);
	startActivity(i);
	break;
	case R.id.btnAddFurnitureSet:
	Intent i11 = new Intent(AdminMenuOptions.this,AddFurnitureSet.class);
	startActivity(i11);
	break;
	case R.id.btnAddSeminarHallThings:
	Intent i2 = new Intent(AdminMenuOptions.this,AddSeminarHallThings.class);
	startActivity(i2);
	break;
	case R.id.btnRequestApproval:
	Intent i3 = new Intent(AdminMenuOptions.this,RequestApproval.class);
	startActivity(i3);
	break;
	case R.id.btnViewAvailability:
	Intent i4 = new Intent(AdminMenuOptions.this,ViewAvailability.class);
	startActivity(i4);
	break;
	case R.id.btnViewStaff:
	Intent i12 = new Intent(AdminMenuOptions.this,ViewStaff.class);
	startActivity(i12);
	break;
	case R.id.btnViewFurnitureSet:
	Intent i13 = new Intent(AdminMenuOptions.this,ViewFurnitureSet.class);
	startActivity(i13);
	break;
	case R.id.btnViewSeminarHallThings:
	Intent i14 = new Intent(AdminMenuOptions.this,ViewSeminarHallThings.class);
	startActivity(i14);
	break;
	case R.id.btnAddLabAttendar:
	Intent i15 = new Intent(AdminMenuOptions.this,AddLabAttendar.class);
	startActivity(i15);
	break;
	case R.id.btnViewLabAttendar:
	Intent i16 = new Intent(AdminMenuOptions.this,ViewLabAttendar.class);
	startActivity(i16);
	break;
	case R.id.btnSearchApproval:
		Intent i161 = new Intent(AdminMenuOptions.this,ViewAvailabilitySeminarHallThings.class);
		startActivity(i161);
		break;
	case R.id.btnViewFSAvailable:
		Intent i162 = new Intent(AdminMenuOptions.this,ViewFurnitureSetAvailable.class);
		startActivity(i162);
		break;
	case R.id.btnExit:
		cls.LoggedUserId="";
		cls.LoggedUserType="";
		Intent i42 = new Intent(AdminMenuOptions.this,Home.class);
		startActivity(i42);
	
	break;
	}
	}
	}
}
