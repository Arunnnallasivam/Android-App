package com.example.furnitureallocation;



import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;

public class StaffMenuOptions extends Activity {
	Button b1,b2,b3,b4,b5,b6,b7,b8;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_staff_menu_options);
		
		b1=(Button)findViewById(R.id.btnViewFurnitureSet);
		b2=(Button)findViewById(R.id.btnViewSeminarHallThings);
		b3=(Button)findViewById(R.id.btnMakeRequest);
		b4=(Button)findViewById(R.id.btnViewAvailability);
		b5=(Button)findViewById(R.id.btnViewStaff);
		b6=(Button)findViewById(R.id.btnExit);
		b7=(Button)findViewById(R.id.btnViewAvailabilitySeminarHallThings);
		b8=(Button)findViewById(R.id.btnViewFSAvailable);
		AdminMenuListener m=new AdminMenuListener();
		b1.setOnClickListener((OnClickListener) m);
		b2.setOnClickListener((OnClickListener) m);
		b3.setOnClickListener((OnClickListener) m);
		b4.setOnClickListener((OnClickListener) m);
		b5.setOnClickListener((OnClickListener) m);
		b6.setOnClickListener((OnClickListener) m);
		b7.setOnClickListener((OnClickListener) m);
		b8.setOnClickListener((OnClickListener) m);
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.staff_menu_options, menu);
		return true;
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		// Handle action bar item clicks here. The action bar will
		// automatically handle clicks on the Home/Up button, so long
		// as you specify a parent activity in AndroidManifest.xml.
		int id = item.getItemId();
		if (id == R.id.action_settings) {
			return true;
		}
		return super.onOptionsItemSelected(item);
	}
	class AdminMenuListener implements View.OnClickListener
	{
	@Override
	public void onClick(View v) {
	switch(v.getId())
	{
	case R.id.btnViewFurnitureSet:
	Intent i13 = new Intent(StaffMenuOptions.this,ViewFurnitureSet.class);
	startActivity(i13);
	break;
	case R.id.btnViewSeminarHallThings:
	Intent i14 = new Intent(StaffMenuOptions.this,ViewSeminarHallThings.class);
	startActivity(i14);
	break;
	case R.id.btnMakeRequest:
	Intent i = new Intent(StaffMenuOptions.this,MakeRequest.class);
	startActivity(i);
	break;
	case R.id.btnViewAvailability:
	Intent i4 = new Intent(StaffMenuOptions.this,ViewAvailability.class);
	startActivity(i4);
	break;
	case R.id.btnViewStaff:
	Intent i12 = new Intent(StaffMenuOptions.this,ViewLabAttendar.class);
	startActivity(i12);
	break;
	case R.id.btnViewAvailabilitySeminarHallThings:
		Intent i41 = new Intent(StaffMenuOptions.this,SearchSeminarHallThings.class);
		startActivity(i41);
		break;
	case R.id.btnViewFSAvailable:
		Intent i412= new Intent(StaffMenuOptions.this,ViewFurnitureSetAvailable.class);
		startActivity(i412);
		break;
	case R.id.btnExit:
		cls.LoggedUserId="";
		cls.LoggedUserType="";
		Intent i42 = new Intent(StaffMenuOptions.this,Home.class);
		startActivity(i42);
	
	break;
	}
	}
	}
}
