package com.example.furnitureallocation;



import android.app.Activity;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class AddSeminarHallThings extends Activity {
	 EditText t1,t2,t3;
	 Button b1,b2;
	 SQLiteDatabase mydb=null;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_add_seminar_hall_things);
		
		t1=(EditText)findViewById(R.id.txtId);
		t2=(EditText)findViewById(R.id.txtThingsName);
		t3=(EditText)findViewById(R.id.txtHallName);
		
		
		b1=(Button)findViewById(R.id.btnSave);
		b2=(Button)findViewById(R.id.btnBack);
		
		
			
		myListener1 m=new myListener1();
		b1.setOnClickListener((OnClickListener) m);
		b2.setOnClickListener((OnClickListener) m);
	
		
		mydb=openOrCreateDatabase(cls.dbname,MODE_PRIVATE ,null);
		//mydb.execSQL("Drop Table SeminarHallThings");
		mydb.execSQL("Create Table If Not Exists SeminarHallThings(ThingsId Varchar(10),ThingsName Varchar(15),HallName Varchar(15))");
		mydb.close();
		
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.add_seminar_hall_things, menu);
		return true;
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		// Handle action bar item clicks here. The action bar will
		// automatically handle clicks on the Home/Up button, so long
		// as you specify a parent activity in AndroidManifest.xml.
		int id = item.getItemId();
		if (id == R.id.action_settings) {
			return true;
		}
		return super.onOptionsItemSelected(item);
	}
	class myListener1 implements View.OnClickListener
	{
	@Override
	public void onClick(View v) {
	// TODO Auto-generated method stub

	switch(v.getId())
	{
	case R.id.btnSave:



	String s1=t1.getText().toString();
	String s2=t2.getText().toString();
	String s3=t3.getText().toString();


	if(s1.equals(""))
	{
	t1.requestFocus();
	return;
	}
	if(s2.equals(""))
	{
		t2.requestFocus();
	return;
	}
	if(s3.equals(""))
	{
		t3.requestFocus();
	return;
	}
	

	mydb=openOrCreateDatabase(cls.dbname,MODE_PRIVATE ,null);
	mydb.execSQL("Delete From SeminarHallThings Where ThingsId='" + s1 + "'");
	mydb.execSQL("Insert into SeminarHallThings Values('" + s1 + "','" + s2 + "','" + s3 + "')");
	Toast.makeText(AddSeminarHallThings.this, "SeminarHallThings Details Saved", Toast.LENGTH_LONG).show();
	mydb.close();
	break;
	case R.id.btnBack:
	finish();
	break;
	}
	}
	}
}
