package com.example.furnitureallocation;

import java.util.ArrayList;

import com.example.furnitureallocation.Home.myListener1;

import android.app.Activity;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemSelectedListener;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

public class MakeRequest extends Activity implements OnItemSelectedListener {
	Button b1,b2;
	EditText t1,t2,t3,t4;
	Spinner spnCategory,spnFurnitureId;
	SQLiteDatabase mydb=null;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_make_request);
		
		
		b1=(Button)findViewById(R.id.btnSave);
		b2=(Button)findViewById(R.id.btnBack);
		
		
		myListener1 m=new myListener1();
		b1.setOnClickListener((OnClickListener) m);
		b2.setOnClickListener((OnClickListener) m);
		
		t1=(EditText)findViewById(R.id.txtRequestId);
		t2=(EditText)findViewById(R.id.txtRequiredDate);
		t3=(EditText)findViewById(R.id.txtStaffId);
		t4=(EditText)findViewById(R.id.txtRemarks);
		
		mydb=openOrCreateDatabase(cls.dbname,MODE_PRIVATE ,null);
		
		//mydb.execSQL("Drop Table RequestDetails");
		mydb.execSQL("Create Table If Not Exists RequestDetails(RequestId Varchar(10),RequiredDate Varchar(10),Category Varchar(10), StaffId Varchar(20),FurnitureId Varchar(20),Remarks Varchar(10))");
		mydb.close();
		
		mydb=openOrCreateDatabase(cls.dbname,MODE_PRIVATE ,null);
		Cursor c=mydb.rawQuery("Select Max(RequestId) From RequestDetails",null);
		c.moveToFirst();
		int count=0;
		if(c.isAfterLast()==false)
		{
			count=c.getInt(0);
		}
		c.close();
		t1.setText(new Integer(count+1).toString());
		mydb.close();
		
		t3.setText(cls.LoggedUserId);
		
		spnFurnitureId = (Spinner) findViewById(R.id.spnFurnitureId);
		spnCategory = (Spinner) findViewById(R.id.spnCategory);
		String[] Categ ={"Furniture","SeminarHallThings"};
		spnCategory.setOnItemSelectedListener(this);
		ArrayAdapter a1=new ArrayAdapter(this, android.R.layout.simple_spinner_item,Categ);
		spnCategory.setAdapter(a1);
		spnCategory.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener()
	        {
	          @Override
				public void onItemSelected(AdapterView<?> arg0, View arg1, int arg2, long arg3) {
		        	String SelCate=arg0.getSelectedItem().toString();
	           		if (SelCate.equals("Furniture"))
	           		{
	           			mydb=openOrCreateDatabase(cls.dbname,MODE_PRIVATE ,null);
	           			Cursor cfi=null;
	           			cfi=mydb.rawQuery("Select FurnitureId,Description From FurnitureSet",null);
	           			cfi.moveToFirst();
	           			ArrayList<String> FurnitureId = new ArrayList<String>();
	           			FurnitureId.add("Select");
	           			while(cfi.isAfterLast()==false)
	           			{
	           			FurnitureId.add(cfi.getString(0) + ":" + cfi.getString(1) );	
	           			cfi.moveToNext();
	           			}
	           		    ArrayAdapter<String> dataAdapter2 = new ArrayAdapter<String>(getApplicationContext(),android.R.layout.simple_spinner_item, FurnitureId);
	           	        dataAdapter2.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
	           	        spnFurnitureId.setAdapter(dataAdapter2);
	           	        cfi.close();
	           	        mydb.close();
	           		}
	           		if (SelCate.equals("SeminarHallThings"))
	           		{
	           			mydb=openOrCreateDatabase(cls.dbname,MODE_PRIVATE ,null);
	           			Cursor cti=null;
	           			cti=mydb.rawQuery("Select ThingsId,ThingsName From SeminarHallThings",null);
	           			cti.moveToFirst();
	           			ArrayList<String> ThingsId = new ArrayList<String>();
	           			ThingsId.add("Select");
	           			while(cti.isAfterLast()==false)
	           			{
	           				ThingsId.add(cti.getString(0) + ":" + cti.getString(1) );	
	           				cti.moveToNext();
	           			}
	           		    ArrayAdapter<String> dataAdapter2 = new ArrayAdapter<String>(getApplicationContext(),android.R.layout.simple_spinner_item, ThingsId);
	           	        dataAdapter2.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
	           	        spnFurnitureId.setAdapter(dataAdapter2);
	           	        cti.close();
	           	        mydb.close();
	           		}
				}
				@Override
				public void onNothingSelected(AdapterView<?> arg0) {
					
					
				}
	        });
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.make_request, menu);
		return true;
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		// Handle action bar item clicks here. The action bar will
		// automatically handle clicks on the Home/Up button, so long
		// as you specify a parent activity in AndroidManifest.xml.
		int id = item.getItemId();
		if (id == R.id.action_settings) {
			return true;
		}
		return super.onOptionsItemSelected(item);
	}

	@Override
	public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void onNothingSelected(AdapterView<?> parent) {
		// TODO Auto-generated method stub
		
	}
	
	
	class myListener1 implements View.OnClickListener
	{
	@Override
	public void onClick(View v) {
	//TODO Auto-generated method stub
		try
		{
	switch(v.getId())
	{
	case R.id.btnSave:

	String s1=t1.getText().toString();
	String s2=t2.getText().toString();
	String s3=spnCategory.getSelectedItem().toString();
	String s4=t3.getText().toString();
	String s5=spnFurnitureId.getSelectedItem().toString().split(":")[0];
	String s6=t4.getText().toString();

	if(s1.equals(""))
	{
	t1.requestFocus();
	return;
	}
	if(s2.equals(""))
	{
	t2.requestFocus();
	return;
	}
	if(s3.equals(""))
	{
		spnCategory.requestFocus();
	return;
	}
	if(s4.equals(""))
	{
		t3.requestFocus();
	return;
	}
	if(s5.equals(""))
	{
		spnFurnitureId.requestFocus();
	return;
	}
	if(s6.equals(""))
	{
	t4.requestFocus();
	return;
	}
	
	
	mydb=openOrCreateDatabase(cls.dbname,MODE_PRIVATE ,null);
	//mydb.execSQL("Delete From RequestDetails Where RequestId='" + s1 + "'");
	mydb.execSQL("Insert into RequestDetails (RequestId ,RequiredDate ,Category , StaffId ,FurnitureId ,Remarks) Values('" + s1 + "','" + s2 + "','" + s3 + "','"  + s4 + "','"  + s5 + "','" + s6 + "')");
	Toast.makeText(getApplicationContext(), "Request Details Saved", Toast.LENGTH_LONG).show();
	mydb.close();
	
	
	break;
	case R.id.btnBack:
	finish();
	break;
	}
		}
		catch(Exception e)
		{
			Toast.makeText(getApplicationContext(), e.getMessage(), 1000).show();
		}
	}
	}
}
