package com.example.furnitureallocation;

import android.app.Activity;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.Color;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.ViewGroup.LayoutParams;
import android.widget.ScrollView;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;
import android.widget.Toast;

public class ViewAvailability extends Activity {
	TableLayout tl1;
	ScrollView sv;
	SQLiteDatabase mydb=null;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_view_availability);
		

		try
		{
			 tl1 = (TableLayout)findViewById(R.id.myTableLayout);
				
				mydb=openOrCreateDatabase(cls.dbname,MODE_PRIVATE ,null);
				Cursor c=null;
			
		

				c=mydb.rawQuery("Select RequestId,RequiredDate,FurnitureId,Status From ApprovalDetails",null);
				c.moveToFirst();
				
				
				
				////Add new row in Table layout
				 TableRow tr1 = new TableRow(this);
				 TextView b11 = new TextView(this);
				 b11.setText("ALLOCATION DETAILS");
				 tr1.addView(b11);
		         tl1.addView(tr1,new TableLayout.LayoutParams(LayoutParams.FILL_PARENT,LayoutParams.FILL_PARENT)); 
		         tr1.setBackgroundColor(Color.WHITE);
				 ////////////////////////////
		         
		         TableRow tr11 = new TableRow(this);
		         TextView b12 = new TextView(this);
		         b12.setText("Records List");
		         tr11.addView(b12);
		         tl1.addView(tr11,new TableLayout.LayoutParams(LayoutParams.FILL_PARENT,LayoutParams.FILL_PARENT));
		         tr11.setBackgroundColor(Color.WHITE);
		         //////////////////////////////
		         
		         TableRow trheader = new TableRow(this);
		         TextView bheader1 = new TextView(this);
		         TextView bheader2 = new TextView(this);
		         TextView bheader3 = new TextView(this);
		         TextView bheader4 = new TextView(this);
		        
		         
		         tl1.addView(trheader,new TableLayout.LayoutParams(LayoutParams.FILL_PARENT,LayoutParams.FILL_PARENT));
		         trheader.setBackgroundColor(Color.WHITE);

		        
		         bheader1.setText("RequestId		");
		         trheader.addView(bheader1);
		         bheader2.setText("Required Date	");
		         trheader.addView(bheader2);
		         bheader3.setText("Furniture Id		");
		         trheader.addView(bheader3);
		         bheader4.setText("Status			");
		         trheader.addView(bheader4);   
		       
		         
		         int rowcount=0;
		         
		              
		         while (c.isAfterLast()==false)
			     {
				
			            
			             TableRow tr = new TableRow(this);
			          
			            
			                  TextView b1 = new TextView(this);
			                  b1.setText(c.getString(0));
			                  //  b1.setWidth(50);
			                 
			                  TextView b2 = new TextView(this);
			                  b2.setText(c.getString(1));
			                  //b2.setWidth(150);
			                  b2.setTextColor(Color.BLACK);;
			                    
			                  TextView b3 = new TextView(this);
			                  b3.setText(c.getString(2));
			                  //b3.setWidth(150);
			                  b3.setTextColor(Color.BLACK);
			                    
			                  TextView b4 = new TextView(this);
			                  b4.setText(c.getString(3));
			                  //b3.setWidth(150);
			                  b4.setTextColor(Color.BLACK);
			                			          
			               
			                			          
			                  
						      tr.addView(b1);
				              tr.addView(b2);
				              tr.addView(b3);           
				              tr.addView(b4); 
				             
						     
			                   tl1.addView(tr,new TableLayout.LayoutParams(LayoutParams.FILL_PARENT,LayoutParams.FILL_PARENT));
			                  // tl1.addView(tr12,new TableLayout.LayoutParams(LayoutParams.FILL_PARENT,LayoutParams.FILL_PARENT));
			                 //  tl1.addView(tr13,new TableLayout.LayoutParams(LayoutParams.FILL_PARENT,LayoutParams.FILL_PARENT));
			                   if(rowcount%2==0)
			                   {
			                	   tr.setBackgroundColor(Color.WHITE);
			                	 //  tr12.setBackgroundColor(Color.BLUE);
			                	//   tr13.setBackgroundColor(Color.BLUE);
			                	   b1.setTextColor(Color.BLACK);
			                	   b2.setTextColor(Color.BLACK);
			                	   b3.setTextColor(Color.BLACK);
			                	   b4.setTextColor(Color.BLACK);
			                	  
			                	
			                   }
			                   else
			                   {
			                	   tr.setBackgroundColor(Color.WHITE);
			                	  // tr12.setBackgroundColor(Color.GREEN);
			                	//   tr13.setBackgroundColor(Color.GREEN);
			                	   b1.setTextColor(Color.BLACK);
			                	   b2.setTextColor(Color.BLACK);
			                	   b3.setTextColor(Color.BLACK);
			                	   b4.setTextColor(Color.BLACK);
			                	
			                
			                   }
			                   rowcount++;
			                   c.moveToNext();
			         }
				c.close();
			//t1.setText(sb1.toString());
				mydb.close();
		}
		catch(Exception e)
		{
			Toast.makeText(getApplicationContext(), e.getMessage().toString(),1000).show();
		}
		
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.view_availability, menu);
		return true;
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		// Handle action bar item clicks here. The action bar will
		// automatically handle clicks on the Home/Up button, so long
		// as you specify a parent activity in AndroidManifest.xml.
		int id = item.getItemId();
		if (id == R.id.action_settings) {
			return true;
		}
		return super.onOptionsItemSelected(item);
	}
}
