package com.example.furnitureallocation;


import android.app.Activity;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;

public class Home extends Activity {
	Button b1,b2,b3;
	SQLiteDatabase mydb=null;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_home);
		
		b1=(Button)findViewById(R.id.btnAdmin);
		b2=(Button)findViewById(R.id.btnStaff);
		b3=(Button)findViewById(R.id.btnExit);
		
		myListener1 m=new myListener1();
		b1.setOnClickListener((OnClickListener) m);
		b2.setOnClickListener((OnClickListener) m);
		b3.setOnClickListener((OnClickListener) m);
		mydb=openOrCreateDatabase(cls.dbname,MODE_PRIVATE ,null);
		mydb.execSQL("Create Table If Not Exists FurnitureSet(FurnitureId Varchar(10),Description Varchar(15))");
		mydb.execSQL("Create Table If Not Exists SeminarHallThings(ThingsId Varchar(10),ThingsName Varchar(15),HallName Varchar(15))");
		mydb.execSQL("Create Table If Not Exists RequestDetails(RequestId Varchar(10),RequiredDate Varchar(10),Category Varchar(10), StaffId Varchar(20),FurnitureId Varchar(20),Remarks Varchar(10))");
		mydb.execSQL("Create Table If Not Exists ApprovalDetails(RequestId Varchar(10),RequiredDate Varchar(10),FurnitureId Varchar(15),Status Varchar(20))");
		mydb.close();
      
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.home, menu);
		return true;
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		// Handle action bar item clicks here. The action bar will
		// automatically handle clicks on the Home/Up button, so long
		// as you specify a parent activity in AndroidManifest.xml.
		int id = item.getItemId();
		if (id == R.id.action_settings) {
			return true;
		}
		return super.onOptionsItemSelected(item);
	}
	class myListener1 implements View.OnClickListener
	{
	@Override
	public void onClick(View v) {
		switch(v.getId())
		{
		case R.id.btnAdmin:
			Intent i = new Intent(Home.this,AdminLogin.class);
	        startActivity(i);
	        break;
		case R.id.btnStaff:
			Intent i6 = new Intent(Home.this,StaffLogin.class);
	        startActivity(i6);
			break;
		case R.id.btnExit:
			finish();
			break;
		}
	}	
	}
}
